import {test,before,after} from 'node:test';
import assert from 'node:assert/strict';
import {randomUUID,randomBytes} from 'node:crypto';
import {database} from '../services/api/db.mjs';
import {platform} from '../services/api/platform.mjs';
import {migrate} from '../scripts/migrate.mjs';
import {httpServer} from '../services/api/http.mjs';
import {dispatchEngine} from '../services/api/dispatch.mjs';
import {fixtureRouting} from '../services/api/dispatch-routing.mjs';
import {haversine} from '../services/api/dispatch-geometry.mjs';
import {resetDispatchFixtures} from './helpers/reset-dispatch-fixtures.mjs';
import {restaurantService} from '../services/api/restaurant.mjs';
import {restaurantOrderService} from '../services/api/restaurant-orders.mjs';

const url = process.env.TEST_DATABASE_URL;
if (!url || !/^elesend_test(?:_|$)/.test(new URL(url).pathname.slice(1))) {
  throw Error('TEST_DATABASE_URL must point to a dedicated elesend_test database');
}

const db = database(url);
const messages = [];
const routing = fixtureRouting(async (a, b) => ({
  distanceMeters: Math.ceil(haversine(a, b) * 1.35),
  durationSeconds: Math.ceil(haversine(a, b) * 1.35 / 7) + 1,
  geometry: {type: 'LineString', coordinates: [[a.longitude, a.latitude], [b.longitude, b.latitude]]}
}));

const dispatcher = dispatchEngine(db, {routing});
const app = platform(db, {
  otpKey: randomBytes(32).toString('hex'),
  sms: {async send(m) { messages.push(m); }},
  dispatch: dispatcher,
  routing
});

const restService = restaurantService(db);
const restOrderService = restaurantOrderService(db, {platform: app, dispatcher, routing});

let admin, businessOwner, customer, rider;
let server, base;
const pw = 'V10HardenedPassword2026!';

async function account(phone, kind = 'customer', extra = {}) {
  return app.register({phone, password: pw, kind, ...extra});
}

before(async () => {
  await migrate(db);
  await db.query('TRUNCATE users,pricing_policies,restaurants,menu_categories,menu_items,food_orders RESTART IDENTITY CASCADE');
  await resetDispatchFixtures(db);

  await db.query(`INSERT INTO pricing_policies(id, vehicle, base_minor, per_km_minor, per_minute_minor, minimum_minor, commission_bps, active)
    VALUES (gen_random_uuid(), 'motorcycle', 1200, 320, 25, 2000, 1300, true)`);

  admin = await account('0207777001');
  await db.query("UPDATE users SET kind='admin' WHERE id=$1", [admin.id]);
  admin.kind = 'admin';
  for (const p of ['verification:write', 'pricing:write', 'shipments:read', 'dispatch:configure']) {
    await db.query('INSERT INTO permissions VALUES($1,$2)', [admin.id, p]);
  }

  businessOwner = await account('0207777002', 'business', {name: 'Accra Chop House'});
  customer = await account('0207777003', 'customer');
  rider = await account('0207777004', 'rider');

  await app.approve(admin, 'riders', rider.id, 'approved');
  await app.availability(rider, {online: true});

  server = httpServer(db, app, dispatcher, null, null, {
    restaurant: restService,
    restaurantOrders: restOrderService
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  base = 'http://127.0.0.1:' + server.address().port;
});

after(async () => {
  await new Promise(r => server.close(r));
  await db.close();
});

test('ELESEND V10 — Production Hardening & Full Lifecycle Suite', async t => {
  let chopHouse, riceCat, waakyeDish;

  await t.test('1. Merchant Restaurant Creation & Dedicated ?mine=true Query', async () => {
    chopHouse = await restService.createRestaurant(businessOwner, {
      name: 'Accra Chop House',
      phone: '0245556677',
      address: 'Ring Road Central, Accra',
      latitude: 5.5701,
      longitude: -0.2012,
      prepTimeMinutes: 20,
      deliveryRadiusM: 10000,
      cuisine: 'Traditional Ghanaian'
    });
    assert.ok(chopHouse.id);

    const bizLogin = await app.login({phone: businessOwner.phone, password: pw});

    // Test ?mine=true HTTP endpoint
    const resMine = await fetch(`${base}/api/v1/restaurants?mine=true`, {
      headers: {Authorization: `Bearer ${bizLogin.token}`}
    });
    assert.equal(resMine.status, 200);
    const mineList = await resMine.json();
    assert.equal(mineList.length, 1);
    assert.equal(mineList[0].id, chopHouse.id);
    assert.equal(mineList[0].name, 'Accra Chop House');
  });

  await t.test('2. Merchant Menu & Catalog Lifecycle (Category, Dish, Stock Toggle)', async () => {
    const bizLogin = await app.login({phone: businessOwner.phone, password: pw});

    // 1. Create Category via HTTP
    const catRes = await fetch(`${base}/api/v1/restaurants/${chopHouse.id}/categories`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${bizLogin.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({name: 'Special Dishes', displayOrder: 1})
    });
    assert.equal(catRes.status, 200);
    riceCat = await catRes.json();
    assert.equal(riceCat.name, 'Special Dishes');

    // 2. Create Menu Item via HTTP
    const itemRes = await fetch(`${base}/api/v1/restaurants/${chopHouse.id}/items`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${bizLogin.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        categoryId: riceCat.id,
        name: 'Special Waakye with Shito & Egg',
        priceMinor: 4500,
        prepTimeMinutes: 20,
        isAvailable: true
      })
    });
    assert.equal(itemRes.status, 200);
    waakyeDish = await itemRes.json();
    assert.equal(waakyeDish.price_minor, 4500);
    assert.equal(waakyeDish.is_available, true);

    // 3. Toggle Dish Availability (Sold Out / In Stock)
    const toggleRes = await fetch(`${base}/api/v1/restaurants/${chopHouse.id}/items/${waakyeDish.id}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${bizLogin.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({isAvailable: false})
    });
    assert.equal(toggleRes.status, 200);
    const updatedDish = await toggleRes.json();
    assert.equal(updatedDish.is_available, false);

    // Toggle back to available
    const toggleBack = await fetch(`${base}/api/v1/restaurants/${chopHouse.id}/items/${waakyeDish.id}`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${bizLogin.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({isAvailable: true})
    });
    assert.equal(toggleBack.status, 200);
    const availableDish = await toggleBack.json();
    assert.equal(availableDish.is_available, true);
  });

  await t.test('3. Food Quote Customer Phone Normalization (Spaces & Formats)', async () => {
    // Input phone with spaces: "020 777 7003"
    const quoteRes = await restOrderService.quoteFoodOrder(customer, {
      restaurantId: chopHouse.id,
      items: [{itemId: waakyeDish.id, quantity: 1, options: []}],
      deliveryAddress: 'Ridge, Accra',
      deliveryLatitude: 5.5650,
      deliveryLongitude: -0.1980,
      customerPhone: '020 777 7003' // Has spaces!
    });

    assert.ok(quoteRes.subtotalMinor === 4500);
    assert.equal(quoteRes.customerPhone, '0207777003');
  });

  await t.test('4. Shipment List Query Enriched with Pickup & Destination Details', async () => {
    // Book a parcel shipment
    const quote = await app.quote(customer, {
      pickup: {address: 'Accra Mall', latitude: 5.6220, longitude: -0.1740},
      destination: {address: 'Kotoka Airport T3', latitude: 5.6050, longitude: -0.1680},
      vehicle: 'motorcycle',
      recipientPhone: '0241112233',
      weightG: 1200,
      description: 'Document Envelope',
      paymentMethod: 'CASH'
    });

    const booked = await app.book(customer, {quoteId: quote.id}, 'v10-test-idempotency-key-01');
    assert.ok(booked.id);

    // Call app.list(customer)
    const custList = await app.list(customer);
    const found = custList.find(s => s.id === booked.id);
    assert.ok(found);
    assert.ok(found.details, 'details field should be present');
    assert.ok(found.pickup, 'pickup field should be present');
    assert.ok(found.destination, 'destination field should be present');
    assert.equal(found.pickup.address, 'Accra Mall');
    assert.equal(found.destination.address, 'Kotoka Airport T3');
    assert.equal(found.details.description, 'Document Envelope');

    // Assign rider and verify rider's app.list(rider) returns pickup/destination
    await dispatcher.riderPosition(rider, {
      latitude: 5.6200,
      longitude: -0.1750,
      accuracyMeters: 10,
      observedAt: new Date().toISOString()
    });
    const offer = await dispatcher.dispatchShipment(booked.id);
    await app.accept(rider, booked.id, offer.offerId);

    const riderList = await app.list(rider);
    const riderFound = riderList.find(s => s.id === booked.id);
    assert.ok(riderFound);
    assert.ok(riderFound.pickup, 'Rider must have pickup location for turn-by-turn navigation');
    assert.ok(riderFound.destination, 'Rider must have destination location for turn-by-turn navigation');
    assert.equal(riderFound.pickup.latitude, 5.6220);
    assert.equal(riderFound.destination.latitude, 5.6050);
  });
});
